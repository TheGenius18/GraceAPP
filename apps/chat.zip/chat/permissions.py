from rest_framework import permissions
from .models import ChatThread

class IsParticipantInThread(permissions.BasePermission):
    """
    Allow only the patient or therapist in the chat thread to access messages.
    """

    def has_object_permission(self, request, view, obj):
        return obj.patient == request.user or obj.therapist == request.user
